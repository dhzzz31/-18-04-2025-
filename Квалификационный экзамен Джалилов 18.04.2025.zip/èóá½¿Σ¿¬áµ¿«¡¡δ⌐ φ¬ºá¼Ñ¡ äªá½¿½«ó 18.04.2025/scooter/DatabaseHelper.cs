﻿using System;

namespace scooter
{
    internal class DatabaseHelper
    {
        internal object GetManufacturers()
        {
            throw new NotImplementedException();
        }

        internal object GetScooters()
        {
            throw new NotImplementedException();
        }
    }
}